'use client'

import { useEffect, useMemo, useState } from 'react'
import {
  BookOpen,
  Building2,
  ChevronDown,
  CircleUserRound,
  GraduationCap,
  LayoutDashboard,
  LockKeyhole,
  LogIn,
  LogOut,
  Menu,
  Pencil,
  Phone,
  Plus,
  Search,
  Settings,
  Trash2,
  UserRound,
  Users,
  X,
} from 'lucide-react'

type Student = {
  id: string
  name: string
  enrollment: string
  course: string
  semester: string
  email: string
  phone: string
}

const seedStudents: Student[] = [
  { id: '1', name: 'Aarav Patel', enrollment: 'SOCA2024001', course: 'BCA', semester: 'Semester 4', email: 'aarav.patel@silveroak.edu.in', phone: '+91 98765 43210' },
  { id: '2', name: 'Diya Shah', enrollment: 'SOCA2024002', course: 'BCA', semester: 'Semester 6', email: 'diya.shah@silveroak.edu.in', phone: '+91 98234 56120' },
  { id: '3', name: 'Rohan Mehta', enrollment: 'SOCA2024003', course: 'MCA', semester: 'Semester 2', email: 'rohan.mehta@silveroak.edu.in', phone: '+91 97654 32108' },
  { id: '4', name: 'Ananya Desai', enrollment: 'SOCA2024004', course: 'B.Sc. IT', semester: 'Semester 4', email: 'ananya.desai@silveroak.edu.in', phone: '+91 98980 12345' },
  { id: '5', name: 'Vivaan Joshi', enrollment: 'SOCA2024005', course: 'BCA', semester: 'Semester 2', email: 'vivaan.joshi@silveroak.edu.in', phone: '+91 98123 45678' },
  { id: '6', name: 'Ishita Trivedi', enrollment: 'SOCA2024006', course: 'MCA', semester: 'Semester 4', email: 'ishita.trivedi@silveroak.edu.in', phone: '+91 99012 34567' },
]

const courseOptions = ['BCA', 'MCA', 'Python', 'Java', 'Cyber Security', 'DBMS', 'C++']

const navItems = [
  { label: 'Dashboard', icon: LayoutDashboard },
  { label: 'Students', icon: Users },
  { label: 'Courses', icon: BookOpen },
  { label: 'Departments', icon: Building2 },
]

export default function Page() {
  const [students, setStudents] = useState<Student[]>(seedStudents)
  const [search, setSearch] = useState('')
  const [activeNav, setActiveNav] = useState('Dashboard')
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState<Student | null>(null)
  const [mobileNav, setMobileNav] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  useEffect(() => {
    setIsAuthenticated(window.localStorage.getItem('silver-oak-authenticated') === 'true')
  }, [])

  function login(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    window.localStorage.setItem('silver-oak-authenticated', 'true')
    setIsAuthenticated(true)
  }

  function logout() {
    window.localStorage.removeItem('silver-oak-authenticated')
    setIsAuthenticated(false)
  }

  useEffect(() => {
    const stored = window.localStorage.getItem('silver-oak-students')
    if (stored) setStudents(JSON.parse(stored))
  }, [])

  useEffect(() => {
    window.localStorage.setItem('silver-oak-students', JSON.stringify(students))
  }, [students])

  const filteredStudents = useMemo(() => students.filter((student) => {
    const query = search.toLowerCase()
    return student.name.toLowerCase().includes(query) || student.enrollment.toLowerCase().includes(query)
  }), [students, search])

  function openAdd() {
    setEditing(null)
    setShowModal(true)
  }

  function openEdit(student: Student) {
    setEditing(student)
    setShowModal(true)
  }

  function removeStudent(id: string) {
    if (window.confirm('Delete this student record?')) setStudents((current) => current.filter((student) => student.id !== id))
  }

  function saveStudent(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const student: Student = {
      id: editing?.id ?? crypto.randomUUID(),
      name: String(form.get('name')),
      enrollment: String(form.get('enrollment')),
      course: String(form.get('course')),
      semester: String(form.get('semester')),
      email: String(form.get('email')),
      phone: String(form.get('phone')),
    }
    setStudents((current) => editing ? current.map((item) => item.id === editing.id ? student : item) : [student, ...current])
    setShowModal(false)
  }

  if (!isAuthenticated) {
    return (
      <main className="grid min-h-screen place-items-center bg-[#f5f8fc] px-5 py-10 text-slate-900">
        <section className="w-full max-w-md rounded-3xl border border-slate-200 bg-white p-7 shadow-xl shadow-blue-950/5 sm:p-9" aria-labelledby="login-title">
          <div className="mb-8 text-center"><img src="/silver-oak-logo.svg" alt="Silver Oak University logo" className="mx-auto mb-5 h-16 w-auto" /><p className="text-xs font-bold uppercase tracking-[0.18em] text-[#1d62ad]">Silver Oak University</p><h1 id="login-title" className="mt-2 text-2xl font-bold tracking-tight">Student Management System</h1><p className="mt-2 text-sm text-slate-500">Sign in to manage college records.</p></div>
          <form onSubmit={login} className="flex flex-col gap-4"><FormField label="Email address" name="email" type="email" placeholder="admin@silveroak.edu.in" required /><FormField label="Password" name="password" type="password" placeholder="Enter your password" required /><button type="submit" className="mt-2 inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-[#1262b3] text-sm font-semibold text-white shadow-sm transition hover:bg-[#0d4f94]"><LogIn className="size-4" />Log in</button></form>
          <p className="mt-5 flex items-center justify-center gap-2 text-center text-xs text-slate-400"><LockKeyhole className="size-3.5" />Demo access: any email and password</p>
        </section>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-[#f5f8fc] text-slate-900">
      <div className="flex min-h-screen">
        <aside className={`fixed inset-y-0 left-0 z-30 flex w-72 flex-col bg-[#073b7a] text-white transition-transform lg:static lg:translate-x-0 ${mobileNav ? 'translate-x-0' : '-translate-x-full'}`}>
          <div className="flex items-center gap-3 border-b border-white/10 px-7 py-7">
            <div className="grid size-11 place-items-center rounded-xl bg-white text-[#073b7a]"><GraduationCap /></div>
            <div><p className="text-sm font-bold tracking-wide">SILVER OAK</p><p className="text-[10px] uppercase tracking-[0.18em] text-blue-200">University</p></div>
          </div>
          <div className="px-4 py-7"><p className="px-3 pb-3 text-[10px] font-bold uppercase tracking-[0.2em] text-blue-200">Main menu</p><nav className="flex flex-col gap-1">{navItems.map(({ label, icon: Icon }) => <button key={label} onClick={() => { setActiveNav(label); setMobileNav(false) }} className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium transition ${activeNav === label ? 'bg-white text-[#073b7a] shadow-lg shadow-blue-950/10' : 'text-blue-100 hover:bg-white/10'}`}><Icon className="size-[18px]" />{label}</button>)}</nav></div>
          <div className="mt-auto p-4"><button className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium text-blue-100 hover:bg-white/10"><Settings className="size-[18px]" />Settings</button><div className="mt-5 rounded-2xl bg-[#0b4d96] p-4"><p className="text-xs font-semibold">Need help?</p><p className="mt-1 text-xs leading-5 text-blue-200">Contact the admin office for support.</p></div></div>
        </aside>

        <section className="min-w-0 flex-1">
          <header className="flex h-[78px] items-center justify-between border-b border-slate-200 bg-white px-5 sm:px-8 lg:px-10">
            <div className="flex items-center gap-3"><button onClick={() => setMobileNav(true)} aria-label="Open navigation" className="rounded-lg p-2 hover:bg-slate-100 lg:hidden"><Menu /></button><img src="/silver-oak-logo.svg" alt="Silver Oak University logo" className="hidden h-11 w-auto sm:block" /><div><p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#1d62ad]">Silver Oak University</p><h1 className="text-sm font-semibold text-slate-700 sm:text-base">Silver Oak College of Computer Application</h1></div></div>
            <div className="flex items-center gap-3"><div className="hidden text-right sm:block"><p className="text-sm font-semibold">Admin Office</p><p className="text-xs text-slate-400">Administrator</p></div><div className="grid size-10 place-items-center rounded-full bg-blue-50 text-[#1262b3]"><CircleUserRound /></div><button onClick={logout} className="hidden items-center gap-1.5 rounded-lg px-2 py-2 text-xs font-semibold text-slate-500 hover:bg-slate-100 sm:flex" aria-label="Log out"><LogOut className="size-4" />Logout</button><ChevronDown className="hidden size-4 text-slate-400 sm:block" /></div>
          </header>

          <div className="mx-auto max-w-[1440px] px-5 py-7 sm:px-8 lg:px-10 lg:py-9">
            <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="mb-2 text-sm font-medium text-[#1d62ad]">Tuesday, October 21, 2026</p><h2 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">Good morning, Admin</h2><p className="mt-1 text-sm text-slate-500">Here&apos;s what&apos;s happening across your college today.</p></div><button onClick={openAdd} className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-[#1262b3] px-5 text-sm font-semibold text-white shadow-sm shadow-blue-200 transition hover:bg-[#0d4f94]"><Plus className="size-4" />Add new student</button></div>

            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              <StatCard label="Total students" value={students.length} note="Active student records" icon={Users} tint="blue" />
              <StatCard label="Total courses" value={courseOptions.length} note="Across all departments" icon={BookOpen} tint="orange" />
              <StatCard label="Departments" value="04" note="Academic departments" icon={Building2} tint="green" />
            </div>

            {activeNav === 'Courses' && <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{courseOptions.map((course) => <div key={course} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><BookOpen className="size-5 text-[#1262b3]" /><h3 className="mt-4 font-bold text-slate-800">{course}</h3><p className="mt-1 text-xs text-slate-400">Available course</p></div>)}</div>}

            <div className="mt-8 rounded-2xl border border-slate-200 bg-white shadow-sm"><div className="flex flex-col gap-4 border-b border-slate-100 px-5 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-7"><div><h3 className="font-bold text-slate-900">Student directory</h3><p className="mt-1 text-xs text-slate-400">Manage and view all enrolled students</p></div><div className="relative w-full sm:w-72"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search by name or enrollment..." aria-label="Search students" className="h-10 w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 text-sm outline-none transition focus:border-[#1262b3] focus:ring-2 focus:ring-blue-100" /></div></div><div className="overflow-x-auto"><table className="w-full min-w-[800px] text-left"><thead className="bg-slate-50/70 text-[11px] uppercase tracking-wider text-slate-400"><tr><th className="px-7 py-4 font-semibold">Student</th><th className="px-4 py-4 font-semibold">Enrollment no.</th><th className="px-4 py-4 font-semibold">Course</th><th className="px-4 py-4 font-semibold">Semester</th><th className="px-4 py-4 font-semibold">Contact</th><th className="px-7 py-4 text-right font-semibold">Actions</th></tr></thead><tbody className="divide-y divide-slate-100">{filteredStudents.map((student) => <tr key={student.id} className="text-sm transition hover:bg-blue-50/30"><td className="px-7 py-4"><div className="flex items-center gap-3"><div className="grid size-9 shrink-0 place-items-center rounded-full bg-blue-100 text-xs font-bold text-[#1262b3]">{student.name.split(' ').map((part) => part[0]).join('')}</div><div><p className="font-semibold text-slate-700">{student.name}</p><p className="mt-0.5 text-xs text-slate-400">{student.email}</p></div></div></td><td className="px-4 py-4 font-medium text-slate-600">{student.enrollment}</td><td className="px-4 py-4"><span className="rounded-md bg-blue-50 px-2.5 py-1 text-xs font-semibold text-[#1262b3]">{student.course}</span></td><td className="px-4 py-4 text-slate-600">{student.semester}</td><td className="px-4 py-4"><div className="flex items-center gap-1.5 text-xs text-slate-500"><Phone className="size-3.5" />{student.phone}</div></td><td className="px-7 py-4"><div className="flex justify-end gap-1"><button onClick={() => openEdit(student)} aria-label={`Edit ${student.name}`} className="rounded-lg p-2 text-slate-400 hover:bg-blue-50 hover:text-[#1262b3]"><Pencil className="size-4" /></button><button onClick={() => removeStudent(student.id)} aria-label={`Delete ${student.name}`} className="rounded-lg p-2 text-slate-400 hover:bg-red-50 hover:text-red-600"><Trash2 className="size-4" /></button></div></td></tr>)}</tbody></table>{filteredStudents.length === 0 && <div className="px-6 py-16 text-center"><UserRound className="mx-auto size-8 text-slate-300" /><p className="mt-3 text-sm font-semibold text-slate-600">No students found</p><p className="mt-1 text-xs text-slate-400">Try a different search term.</p></div>}</div><div className="border-t border-slate-100 px-7 py-4 text-xs text-slate-400">Showing <span className="font-semibold text-slate-600">{filteredStudents.length}</span> of <span className="font-semibold text-slate-600">{students.length}</span> students</div></div>
          </div>
        </section>
      </div>

      {mobileNav && <button aria-label="Close navigation overlay" onClick={() => setMobileNav(false)} className="fixed inset-0 z-20 bg-slate-950/30 lg:hidden" />}
      {showModal && <div className="fixed inset-0 z-40 grid place-items-center bg-slate-950/40 p-4"><div role="dialog" aria-modal="true" aria-labelledby="student-modal-title" className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl sm:p-7"><div className="mb-6 flex items-start justify-between"><div><h2 id="student-modal-title" className="text-xl font-bold">{editing ? 'Edit student' : 'Add new student'}</h2><p className="mt-1 text-sm text-slate-500">Enter the student&apos;s academic and contact details.</p></div><button onClick={() => setShowModal(false)} aria-label="Close dialog" className="rounded-lg p-2 text-slate-400 hover:bg-slate-100"><X /></button></div><form onSubmit={saveStudent} className="grid gap-4 sm:grid-cols-2"><FormField label="Full name" name="name" defaultValue={editing?.name} required /><FormField label="Enrollment number" name="enrollment" defaultValue={editing?.enrollment} required /><label className="flex flex-col gap-1.5 text-sm font-medium text-slate-600">Course<select name="course" defaultValue={editing?.course ?? courseOptions[0]} required className="h-10 rounded-lg border border-slate-200 bg-white px-3 text-sm font-normal text-slate-800 outline-none focus:border-[#1262b3] focus:ring-2 focus:ring-blue-100">{courseOptions.map((course) => <option key={course} value={course}>{course}</option>)}</select></label><FormField label="Semester" name="semester" defaultValue={editing?.semester} placeholder="e.g. Semester 4" required /><FormField label="Email address" name="email" type="email" defaultValue={editing?.email} required /><FormField label="Phone number" name="phone" defaultValue={editing?.phone} required /><div className="mt-2 flex gap-3 sm:col-span-2"><button type="button" onClick={() => setShowModal(false)} className="h-11 flex-1 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600 hover:bg-slate-50">Cancel</button><button type="submit" className="h-11 flex-1 rounded-xl bg-[#1262b3] text-sm font-semibold text-white hover:bg-[#0d4f94]">{editing ? 'Save changes' : 'Add student'}</button></div></form></div></div>}
    </main>
  )
}

function StatCard({ label, value, note, icon: Icon, tint }: { label: string; value: string | number; note: string; icon: typeof Users; tint: 'blue' | 'orange' | 'green' }) {
  const colors = { blue: 'bg-blue-50 text-[#1262b3]', orange: 'bg-orange-50 text-orange-600', green: 'bg-emerald-50 text-emerald-600' }
  return <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="flex items-start justify-between"><div><p className="text-sm font-medium text-slate-500">{label}</p><p className="mt-3 text-3xl font-bold tracking-tight text-slate-900">{value}</p></div><div className={`grid size-11 place-items-center rounded-xl ${colors[tint]}`}><Icon className="size-5" /></div></div><p className="mt-5 text-xs text-slate-400">{note}</p></div>
}

function FormField({ label, name, type = 'text', defaultValue, placeholder, required }: { label: string; name: string; type?: string; defaultValue?: string; placeholder?: string; required?: boolean }) {
  return <label className="flex flex-col gap-1.5 text-sm font-medium text-slate-600">{label}<input name={name} type={type} defaultValue={defaultValue} placeholder={placeholder} required={required} className="h-10 rounded-lg border border-slate-200 px-3 text-sm font-normal text-slate-800 outline-none placeholder:text-slate-300 focus:border-[#1262b3] focus:ring-2 focus:ring-blue-100" /></label>
}
